import { getCreativeWorks } from '../lib/shopify';

export default async function Home() {
  const works = await getCreativeWorks();

  return (
    <main>
      <div className="grain" />
      <header className="site-header">
        <a className="monogram" href="#top" aria-label="The Transcendent Recursion home">TR<span>∞</span></a>
        <nav aria-label="Main navigation"><a href="#works">The works</a><a href="#about">The premise</a><a className="header-index" href="#index">Index <span>↘</span></a></nav>
      </header>
      <section className="hero" id="top"><div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" /><div className="hero-inner"><p className="kicker"><span className="pulse" /> A creative outlet by Anthony Castro</p><h1>The<br /><em>Transcendent</em><br />Recursion</h1><p className="hero-intro">A multiverse in progress.<br />Books, sound, physics, and transmissions<br />from the edge of the known self.</p><a className="scroll-cue" href="#works"><span>↓</span> Enter the multiverse</a></div><div className="hero-aside"><span>TR / 001</span><span>Signal received<br />2024 — ∞</span></div></section>
      <section className="manifesto" id="about"><p className="kicker">/// The premise</p><div className="manifesto-layout"><h2>There is no<br /><em>outside.</em></h2><div className="manifesto-copy"><p>The Transcendent Recursion is a living body of work about the moment reality notices itself.</p><p>It begins as a story and keeps unfolding: into a novel, a score, a theory of everything, a declaration of independence from inherited technology, and a map back to the source.</p><span className="coordinates">35° 40&apos; N / 139° 41&apos; E<br />ALL SYSTEMS ARE STORIES</span></div></div></section>
      <section className="works" id="works"><div className="section-top"><div><p className="kicker">/// The archive</p><h2>One outlet.<br /><em>Many worlds.</em></h2></div><p className="section-note">A sequence of connected works<br />for crossing the threshold.</p></div>{works.length > 0 ? <div className="work-list">{works.map((work) => <article className={`work-card ${work.theme}`} key={work.number} id={work.href.replace(/^#/, '')}><div className="card-art"><span className="work-number">{work.number}</span><div className="art-symbol" aria-hidden="true" /></div><div className="work-content"><p className="work-type">{work.type}</p><h3>{work.title}</h3><p className="work-description">{work.description}</p><a className="work-link" href={work.href}>{work.action} <span>↗</span></a><span className="status">{work.status}</span></div></article>)}</div> : <p className="archive-empty">Connect the Shopify Storefront API and publish your first <code>creative_work</code> metaobject to open the archive.</p>}</section>
      <section className="closing" id="index"><div className="closing-mark">∞</div><div className="closing-copy"><p className="kicker">/// Transmission open</p><h2>Follow the<br /><em>signal.</em></h2><p>The next transmission arrives when it is ready. Leave a frequency and be the first to hear it.</p><a className="outline-button" href="mailto:signal@transcendentrecursion.com">Open a channel <span>↗</span></a></div></section>
      <footer><a className="monogram" href="#top">TR<span>∞</span></a><span>The Transcendent Recursion / A work in progress</span><span>© 2024 — 2026</span></footer>
    </main>
  );
}